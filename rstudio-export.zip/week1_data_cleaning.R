# Week 1 Titanic data cleaning and preliminary analysis
# Base R only. Run from this folder: Rscript week1_data_cleaning.R
args <- commandArgs(trailingOnly=TRUE)
input <- if(length(args)) args[1] else 'train.csv'
dir.create('tables', showWarnings=FALSE)
dir.create('plots', showWarnings=FALSE)
sink('R_console_output.txt', split=TRUE)
raw <- read.csv(input, na.strings=c('', 'NA'), stringsAsFactors=FALSE)
cat('RAW DIMENSIONS\n'); print(dim(raw)); str(raw); print(summary(raw))
valid <- !is.na(suppressWarnings(as.numeric(raw$PassengerId))) & !is.na(raw$Survived) & !is.na(raw$Pclass)
write.csv(raw[!valid,], 'tables/rejected_rows.csv', row.names=FALSE)
df <- raw[valid,]; df$PassengerId <- as.integer(df$PassengerId)
cat('Rejected malformed rows:',sum(!valid),'\n')
cat('Exact duplicates:',sum(duplicated(df)),'\n')
df <- df[!duplicated(df),]
missing <- data.frame(variable=names(df), missing=colSums(is.na(df)))
missing$percent <- round(100*missing$missing/nrow(df),2)
write.csv(missing,'tables/missing_values.csv',row.names=FALSE); print(missing)
df$AgeMissing <- as.integer(is.na(df$Age))
df$SexMissing <- as.integer(is.na(df$Sex))
df$NameMissing <- as.integer(is.na(df$Name))
df$EmbarkedMissing <- as.integer(is.na(df$Embarked))
df$HasCabin <- as.integer(!is.na(df$Cabin))
df$Age[is.na(df$Age)] <- median(df$Age,na.rm=TRUE)
mode_value <- function(x) names(sort(table(x),decreasing=TRUE))[1]
df$Embarked[is.na(df$Embarked)] <- mode_value(df$Embarked)
df$Sex[is.na(df$Sex)] <- 'Unknown'
df$Title <- ifelse(is.na(df$Name),'Unknown',sub('^.*, ([^.]+)\\..*$','\\1',df$Name))
df$Title[!df$Title %in% c('Mr','Mrs','Miss','Master','Unknown')] <- 'Other'
df$Cabin <- NULL; df$Name <- NULL; df$Ticket <- NULL
for(v in c('Survived','Pclass','Sex','Embarked','Title')) df[[v]] <- factor(df[[v]])
fences <- function(x) {q<-quantile(x,c(.25,.75),type=7); c(q[1]-1.5*diff(q),q[2]+1.5*diff(q))}
out <- do.call(rbind,lapply(c('Age','Fare','SibSp','Parch'),function(v){f<-fences(df[[v]]); data.frame(variable=v,lower=f[1],upper=f[2],count=sum(df[[v]]<f[1]|df[[v]]>f[2]))}))
rownames(out)<-NULL; print(out); write.csv(out,'tables/outliers.csv',row.names=FALSE)
# Preserve original values. Capping is an optional transformed feature, not error correction.
for(v in c('Age','Fare')) {
 f<-fences(df[[v]]); x<-pmax(f[1],pmin(f[2],df[[v]]))
 df[[paste0(v,'_capped')]]<-x
 df[[paste0(v,'_minmax')]]<-(x-min(x))/(max(x)-min(x))
 df[[paste0(v,'_z')]]<-as.numeric(scale(x))
}
# Build all indicator columns separately to avoid treatment coding of later factors.
for(v in c('Sex','Embarked','Title')) for(level in levels(df[[v]])) df[[paste0(v,'_',level)]]<-as.integer(df[[v]]==level)
df$Pclass_enc<-as.integer(as.character(df$Pclass))
stopifnot(nrow(df)==891,!anyNA(df),!anyDuplicated(df$PassengerId))
write.csv(df,'titanic_cleaned.csv',row.names=FALSE)
num<-c('Age','Fare','SibSp','Parch')
desc<-data.frame(variable=num,mean=sapply(df[num],mean),median=sapply(df[num],median),sd=sapply(df[num],sd),min=sapply(df[num],min),max=sapply(df[num],max))
rownames(desc)<-NULL; print(desc); write.csv(desc,'tables/descriptive_statistics.csv',row.names=FALSE)
y<-as.integer(as.character(df$Survived)); cat('Survivors:',sum(y),'Overall percent:',100*mean(y),'\n')
for(v in c('Sex','Pclass','Embarked')) {
 t<-aggregate(y,list(group=df[[v]]),function(x)c(n=length(x),survived=sum(x),percent=100*mean(x)))
 t<-data.frame(group=t$group,t$x); print(t); write.csv(t,paste0('tables/survival_by_',v,'.csv'),row.names=FALSE)
}
cors<-df[c('Age','Fare','SibSp','Parch','Pclass_enc','HasCabin')]; cors$Survived<-y
cm<-cor(cors); print(round(cm,3)); write.csv(cm,'tables/correlation_matrix.csv')
png('plots/01_missing_values.png',1200,700,res=150); par(mar=c(7,4,3,1)); barplot(missing$percent,names.arg=missing$variable,las=2,col='#287D8E',ylab='Missing values (%)',main='Missing values in valid passenger records'); dev.off()
png('plots/02_outliers.png',1200,800,res=150); par(mfrow=c(2,2)); for(v in c('Age','Fare')) {boxplot(df[[v]],main=paste(v,'original'),col='#287D8E');boxplot(df[[paste0(v,'_capped')]],main=paste(v,'capped'),col='#D7A44B')}; dev.off()
for(v in c('Sex','Pclass','Embarked')) {p<-100*tapply(y,df[[v]],mean);png(paste0('plots/survival_by_',v,'.png'),1100,700,res=150);barplot(p,ylim=c(0,100),col='#287D8E',ylab='Survival (%)',main=paste('Survival by',v));dev.off()}
png('plots/age_distribution.png',1100,700,res=150);hist(df$Age,breaks=30,col='#287D8E',main='Age distribution after median imputation',xlab='Age in years');dev.off()
png('plots/correlation_heatmap.png',1100,900,res=150);par(mar=c(8,8,3,2));image(seq_len(ncol(cm)),seq_len(ncol(cm)),cm,zlim=c(-1,1),col=colorRampPalette(c('#A94442','white','#287D8E'))(100),axes=FALSE,xlab='',ylab='',main='Pearson correlation');axis(1,seq_len(ncol(cm)),colnames(cm),las=2);axis(2,seq_len(ncol(cm)),colnames(cm),las=2);for(i in seq_len(ncol(cm)))for(j in seq_len(ncol(cm)))text(i,j,sprintf('%.2f',cm[i,j]),cex=.7);dev.off()
cat('FINAL STRUCTURE\n');str(df);print(summary(df));cat('Checks passed: 891 unique passengers and no missing values.\n');print(sessionInfo());sink()
